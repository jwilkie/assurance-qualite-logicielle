﻿namespace AssuranceQualiteLogicielle;

public class Program
{
    public static void Main(string[] args)
    {
        int nombre1 = GetEntreeEntierConsole("Entrer le premier nombre: ");
        int nombre2 = GetEntreeEntierConsole("Entrer le deuxième nombre: ");

        Console.WriteLine("Somme: " + Addition(nombre1, nombre2));
        Console.WriteLine("Difference: " + Soustraction(nombre1, nombre2));
        Console.WriteLine("Product: " + Multiplication(nombre1, nombre2));
        Console.WriteLine("Quotient: " + Division(nombre1, nombre2));
        Console.WriteLine("Factoriel: " + Factorial(nombre1));
    }

    public static int GetEntreeEntierConsole(string texte)
    {
        int nombre;
        do 
        {
            Console.Write(texte);
        }
        while(!int.TryParse(Console.ReadLine(), out nombre));

        return nombre;
    }

    static int Addition(int nombre1, int nombre2)
    {
        return nombre1 + nombre2;
    }

    static int Soustraction(int nombre1, int nombre2)
    {
        return nombre1 - nombre2;
    }

    static int Multiplication(int nombre1, int nombre2)
    {
        return nombre1 * nombre2;
    }

    static int Division(int nombre1, int nombre2)
    {
        return nombre1 / nombre2;
    }

    static int Factorial(int nombre)
    {
        int i = nombre;
        while(i != 0) {
            if(nombre > 0) {
                nombre = checked(nombre * i);
                i--;
            }
        }

        return nombre;
    }
}