namespace AssuranceQualiteLogicielle;

/// <summary>
/// Représente un personnage de jeu avec un pointage d'énergie et qui peut 
/// faire quelques actions.
/// </summary>
public class Personnage 
{
    /// <summary>
    /// Point d'énergie restant au personnage.
    /// </summary>
    private int energie;

    /// <summary>
    /// Initialise un nouveau personnage avec 100 points d'énergie.
    /// </summary>
    public Personnage() 
    {
        this.energie = 100;
    }

    /// <summary>
    /// Le personnage mange, gagnant 10 points d'énergie.
    /// </summary>
    public void Manger() 
    {
        this.energie += 10;
    }

    /// <summary>
    /// Le personnage saute, perdant 3 points d'énergie.
    /// </summary>
    public void Sauter()
    {
        this.energie -= 3;
    }

    /// <summary>
    /// Le personnage marche, perdant 1 point d'énergie.
    /// </summary>
    public void Marcher()
    {
        this.energie -= 1;
    }

    /// <summary>
    /// Indique si le personnage a encore de l'énergie ou non. Si le 
    /// personnage n'a plus d'énergie, il doit s'arrêter.
    /// </summary>
    /// <returns>
    /// Une valeur indiquant si le personnage a un pointage d'énergie 
    /// supérieur à 0 ou non.
    /// </returns>
    public bool DoitArreter()
    {
        return this.energie <= 0;
    }
}
