namespace AssuranceQualiteLogicielle;

/// <summary>
/// Un jeu où à chaque étape, un personnage effectue une action lui faisant
/// gagner ou perdre de l'énergie. Le jeu se termine quand le personnage n'a 
/// plus d'énergie.
/// </summary>
public class Jeu 
{
    /// <summary>
    /// Probabilité que le personnage marche lors d'une étape du jeu.
    /// </summary>
    private const float PROBABILITE_MARCHER = 0.7f;

    /// <summary>
    /// Probabilité que le personnage saute lors d'une étape du jeu.
    /// </summary>
    private const float PROBABILITE_SAUTER = 0.2f;

    /// <summary>
    /// Probabilité que le personnage mange lors d'une étape du jeu.
    /// </summary>
    private const float PROBABILITE_MANGER = 0.1f;

    /// <summary>
    /// Personnage utilié pour le jeu.
    /// </summary>
    private Personnage personnage;

    /// <summary>
    /// Randomiseur permettant de générer des nombres aléatoires.
    /// </summary>
    private Random randomiseur;

    /// <summary>
    /// Initialise un nouveau jeu utilisant le germe aléatoire spécifié en 
    /// paramètre. Le germe sert à contrôler la génération de nombres 
    /// aléatoire. Si on utilise toujours le même germe, la série de nombres 
    /// aléatoires générée sera toujours la même.
    /// </summary>
    public Jeu()
    {
        this.personnage = new Personnage();
        this.randomiseur = new Random();
    }

    /// <summary>
    /// Accesseur du personnage utilisé dans le jeu.
    /// </summary>
    /// <returns>Le personnage utilisé dans le jeu.</returns>
    public Personnage GetPersonnage()
    {
        return personnage;
    }

    /// <summary>
    /// Exécute une étape du jeu. À chaque étape, on décide aléatoirement une 
    /// action qui sera entreprise par le personnage. Chaque action a une 
    /// probabilité différente d'être sélectionné et dépendant de l'action 
    /// exécuté, le personnage gagnera ou perdra des points d'énergie.
    /// </summary>
    /// <returns>
    /// Une valeur indiquant si le jeu peut continuer ou non. Le jeu doit 
    /// s'arrêter lorsque le personnage n'a plus d'énergie.
    /// </returns>
    public bool Etape()
    {
        // Génération d'un nombre flottant aléatoire entre 0 et 1
        float nombreAleatoire = randomiseur.NextSingle();

        if(nombreAleatoire <= PROBABILITE_MARCHER)
        {
            // Le nombre est inférieur à 0.7, on marche
            this.personnage.Marcher();
        }
        else if(nombreAleatoire <= PROBABILITE_MARCHER + PROBABILITE_SAUTER)
        {
            // Le nombre est entre 0.7 et 0.9, on saute
            this.personnage.Sauter();
        }
        else if(nombreAleatoire <= PROBABILITE_MARCHER + PROBABILITE_SAUTER + PROBABILITE_MANGER)
        {
            // Le nombre est entre 0.9 et 1, on mange
            this.personnage.Manger();
        }

        // Regarde l'énergie du personnage pour voir si on doit arrêter le jeu
        return !this.personnage.DoitArreter();
    }
}
