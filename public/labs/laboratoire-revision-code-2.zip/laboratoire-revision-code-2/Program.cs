﻿namespace AssuranceQualiteLogicielle;

public class truc()
{
    public static void Main()
    {
        int a;
        bool tesT;
        Console.WriteLine("Combiens de nombres entier voulez-vous entrer?");
    do
    {
        tesT = int.TryParse(Console.ReadLine(), out a);
    }
    while (!tesT);



        int[] nombres = new int[a];
        for (int i = 0; i < nombres.Length; i++)
        {
            Console.WriteLine("Nombre entier #" + (i + 1) + ":");
            do
            {
                tesT = int.TryParse(Console.ReadLine(), out a);
            }
            while (!tesT);
              nombres[i] = a;
        }

        int somme = 0; double MOyenne = 0; int mode = 0; int x = 0;
        for (int i = 0; i < nombres.Length; i++) {
           somme += nombres[i];
        }



        for (int i = 0; i < nombres.Length; i++) { MOyenne += nombres[i]; }
        MOyenne /= nombres.Length;
        for(int i = 0 ; i < nombres.Length ; i++) {
        int Calcul_Mode = 0;
        for(int j = 0 ; j < nombres.Length ; j++) {
            if(nombres[j] == nombres[i]) {
                Calcul_Mode++;
            }}

        if(Calcul_Mode > x) {
          x = Calcul_Mode;
           mode = nombres[i];
        }
        }
        Console.WriteLine("Somme  : " + somme);
        Console.WriteLine("Moyenne: " + MOyenne);
        Console.WriteLine("Mode   : " + mode);
    }
}
