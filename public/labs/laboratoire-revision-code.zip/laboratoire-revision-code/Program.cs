﻿namespace AssuranceQualiteLogicielle;

public class frequencecaractere()
{
    public static void Main() {
        Console.WriteLine("Entrer un texte pour en faire l'analyse des caractères: ");
        string? t;
        do{
         t = Console.ReadLine(); }
        while(string.IsNullOrEmpty(t));
        int[] tab = new int[26]; t = t.ToUpper();
        for(int i = 0; i <   t.Length ; i++  ) {
            char letttre = t[i];
        if(  letttre >=  'A' && letttre <= 'Z') 
        {
            tab[letttre - 'A']++;
        }}




    Console.WriteLine("Analyse des caractères: ");
    for(int i = 0;i < tab.Length; i++) 
        {
            Console.WriteLine("" +      (char)(i  +    'A') + ": "       + String.Format("{0," + t.Length.ToString().Length + "}", tab[i]) +    " / " + t.Length);

        }
    }
}












