﻿namespace AssuranceQualiteLogicielle;

/// <summary>
/// Point d'entrée du programme.
/// </summary>
public class Program 
{
    /// <summary>
    /// Point d'entrée du programme.
    /// </summary>
    public static void Main()
    {
        // Germe utilisé pour le jeu
        const int GERME = 131434654;

        // Initialise le jeu avec le germe ci-dessus
        Jeu jeu = new Jeu(GERME);
        
        // Boucle qui continue tant que le personnage a un pointage d'énergie 
        // supérieur à zéro. À chaque itération de la boucle, on exécute une 
        // étape du jeu.
        int iteration = 0;
        bool continuer = true;
        while(continuer)
        {
            // Exécute une étape du jeu et valide si le jeu peut continuer
            continuer = jeu.Etape();

            // Incrémente l'itération active du jeu
            iteration++;
        }

        // Affichage du nombre d'étapes faites par le personnage à la fin du 
        // jeu
        Console.WriteLine("Le personnage a eu assez d'énergie pour faire " + iteration + " étapes.");
    }
}