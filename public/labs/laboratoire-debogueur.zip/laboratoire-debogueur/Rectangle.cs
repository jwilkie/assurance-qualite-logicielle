namespace AssuranceQualiteLogicielle;

/// <summary>
/// Représente un rectangle dans un espace bidimensionnel.
/// </summary>
public class Rectangle 
{
    /// <summary>
    /// Nom du rectangle pour être capable de le distinguer.
    /// </summary>
    private string nom;

    /// <summary>
    /// Position en X du rectangle dans l'espace bidimensionnel.
    /// </summary>
    private int x;

    /// <summary>
    /// Position en Y du rectangle dans l'espace bidimensionnel.
    /// </summary>
    private int y;

    /// <summary>
    /// La largeur du rectangle.
    /// </summary>
    private int largeur;

    /// <summary>
    /// La hauteur du rectangle.
    /// </summary>
    private int hauteur;

    /// <summary>
    /// Initialise un nouveau rectangle de taille 1 par 1.
    /// </summary>
    public Rectangle() 
    {
        this.nom = "Rectangle";
        this.x = -1;
        this.y = -1;
        this.largeur = 2;
        this.hauteur = 2;
    }

    /// <summary>
    /// Initialise un nouveau rectangle avec les dimensions
    /// passées en paramètre.
    /// </summary>
    /// <param name="x">
    /// La nouvelle coordonnée en X du rectangle.
    /// </param>
    /// <param name="y">
    /// La nouvelle coordonnée en X du rectangle.
    /// </param>
    /// <param name="largeur">
    /// La nouvelle largeur du rectangle. La largeur doit être
    /// supérieure à zéro.
    /// </param>
    /// <param name="hauteur">
    /// La nouvelle hauteur du rectangle. La hauteur doit être 
    /// supérieure à zéro.
    /// </param>
    public Rectangle(string nom, int x, int y, int largeur, int hauteur)
    {
        this.nom = nom;
        this.x = 0;
        this.y = 0;
        this.largeur = 1;
        this.hauteur = 1;
        this.SetX(x);
        this.SetY(y);
        this.SetLargeur(largeur);
        this.SetHauteur(hauteur);
    }

    /// <summary>
    /// Accesseur de la propriété nom du rectangle.
    /// </summary>
    /// <returns>Le nom du rectangle.</returns>
    public string GetNom() 
    {
        return this.nom;
    }

    /// <summary>
    /// Accesseur de la propriété x du rectangle.
    /// </summary>
    /// <returns>La coordonnée en x du rectangle.</returns>
    public int GetX() 
    {
        return this.x;
    }

    /// <summary>
    /// Mutateur de la propriété x du rectangle.
    /// </summary>
    /// <param name="x">
    /// La nouvelle coordonnée en x du rectangle.
    /// </param>
    public void SetX(int x)
    {
        this.x = x;
    }

    /// <summary>
    /// Accesseur de la propriété y du rectangle.
    /// </summary>
    /// <returns>La coordonnée en y du rectangle.</returns>
    public int GetY() 
    {
        return this.y;
    }

    /// <summary>
    /// Mutateur de la propriété y du rectangle.
    /// </summary>
    /// <param name="y">
    /// La nouvelle coordonnée en y du rectangle.
    /// </param>
    public void SetY(int y)
    {
        this.y = y;
    }

    /// <summary>
    /// Accesseur de la propriété largeur du rectangle.
    /// </summary>
    /// <returns>La largeur du rectangle.</returns>
    public int GetLargeur() 
    {
        return this.largeur;
    }

    /// <summary>
    /// Mutateur de la propriété largeur du rectangle.
    /// </summary>
    /// <param name="largeur">
    /// La nouvelle largeur du rectangle. La largeur doit être
    /// supérieure à zéro.
    /// </param>
    public void SetLargeur(int largeur)
    {
        if(largeur > 0)
        {
            this.largeur = largeur;
        }
    }

    /// <summary>
    /// Accesseur de la propriété hauteur du rectangle.
    /// </summary>
    /// <returns>La hauteur du rectangle.</returns>
    public int GetHauteur() 
    {
        return this.hauteur;
    }

    /// <summary>
    /// Mutateur de la propriété hauteur du rectangle.
    /// </summary>
    /// <param name="hauteur">
    /// La nouvelle hauteur du rectangle. La hauteur doit être 
    /// supérieure à zéro.
    /// </param>
    public void SetHauteur(int hauteur)
    {
        if(hauteur > 0)
        {
            this.hauteur = hauteur;
        }
    }

    /// <summary>
    /// Calcule l'aire de la surface du rectangle.
    /// </summary>
    /// <returns>La taille de la surface du rectangle.</returns>
    public int Aire() 
    {
        return this.largeur * this.hauteur;
    }

    /// <summary>
    /// Calcule le périmètre du rectangle.
    /// </summary>
    /// <returns>La taille du contour du rectangle.</returns>
    public int Perimetre() 
    {
        return this.largeur * 2 + this.hauteur * 2;
    }

    /// <summary>
    /// Calcule et retourne si le rectangle courant entre en collision avec un 
    /// autre rectangle passé en paramètre.
    /// </summary>
    /// <param name="autreRectangle">
    /// L'autre rectangle avec lequel on calcule s'il y a une collision.
    /// </param>
    /// <returns>
    /// Une valeur indiquant s'il y a collision entre les deux rectangles ou 
    /// non.
    /// </returns>
    public bool Collision(Rectangle autreRectangle)
    {
        return this.x + this.largeur >= autreRectangle.x &&
            this.x <= autreRectangle.x + autreRectangle.largeur &&
            this.y + this.hauteur >= autreRectangle.y &&
            this.y <= autreRectangle.y + autreRectangle.hauteur;
    }
}
