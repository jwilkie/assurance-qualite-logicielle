﻿namespace AssuranceQualiteLogicielle;

public class Program()
{
    /// <summary>
    /// Point d'entrée principal du programme.
    /// </summary>
    public static void Main()
    {
        // Création des rectangles
        Rectangle[] rectangles =
        [
            new Rectangle("A", 8, 1, 2, 3),
            new Rectangle("B", 5, 0, 2, 4),
            new Rectangle("C", 7, 5, 4, 3),
            new Rectangle("D", 7, 9, 4, 2),
            new Rectangle("E", 2, 6, 2, 1),
            new Rectangle("F", 0, 8, 3, 2),
            new Rectangle("G", 1, 1, 3, 2),
            new Rectangle("H", 5, 6, 3, 2),
            new Rectangle("I", 5, 9, 1, 2),
            new Rectangle("J", 0, 4, 3, 1),
        ];

        // Test de collision
        TestCollision(rectangles);
    }

    /// <summary>
    /// Teste si des collisions existent entre les rectangles passés en 
    /// paramètre.
    /// </summary>
    /// <param name="rectangles">
    /// Tableau de rectangles.
    /// </param>
    public static void TestCollision(Rectangle[] rectangles)
    {
        bool collision = false;
        for (int i = 0; i < rectangles.Length - 1; i++)
        {
            for (int j = i + 1; j < rectangles.Length; j++)
            {
                if(rectangles[i].Collision(rectangles[j]))
                {
                    collision = true;
                }
            }
        }

        if(collision)
        {
            Console.WriteLine("Collision entre 2 rectangles");
        }
        else 
        {
            Console.WriteLine("Aucune collision");
        }
    }
}
